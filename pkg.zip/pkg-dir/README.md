# netuitive-packages-aws-efs
A set of Netuitive analytics configurations, polices, dashboards, and reports that are used to monitor performance of AWS Elastic File System (EFS) resources.
